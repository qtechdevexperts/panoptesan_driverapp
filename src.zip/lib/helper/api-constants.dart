class ApiConstants {
    static String baseUrl = 'https://panoptesan.thesuitchstaging.com:9090/driver';
    static String loginEndpoint = '/login';
    static String registerEndpoint = '/register';
}