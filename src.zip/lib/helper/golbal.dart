String loginType = "";
bool request = false;
bool card = false;
bool signUp = false;
